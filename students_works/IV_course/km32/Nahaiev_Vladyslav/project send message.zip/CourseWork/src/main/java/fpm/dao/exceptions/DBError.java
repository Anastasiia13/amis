package fpm.dao.exceptions;

public class DBError extends Exception{
    public DBError(Throwable e){
        initCause(e);
    }
}
