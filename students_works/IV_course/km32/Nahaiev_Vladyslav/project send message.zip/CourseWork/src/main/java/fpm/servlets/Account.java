package fpm.servlets;

import fpm.dao.oracle.table.UsersOracleDAO;
import fpm.dao.table.UsersDAO;
import fpm.entities.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/account")

public class Account extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        HttpSession session;
        User user = new User();
        UsersDAO edit = new UsersOracleDAO();
        session = req.getSession();
        try {
            if (session.getAttribute("authUser") != null) {
                user.setEmail(session.getAttribute("authUser").toString());
                String[] info = edit.userInfo(user);
                session.setAttribute("name_surname",info[0]);
                session.setAttribute("about",info[1]);
                session.setAttribute("birthday",info[2]);

            } else {
                resp.sendRedirect(Denied.redict());
                return;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        req.getRequestDispatcher("account.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        User user = new User();
        UsersOracleDAO usersOracleDAO = new UsersOracleDAO();
        HttpSession session = req.getSession(true);

        user.setFullName(req.getParameter("e_fullname"));
        user.setAbout(req.getParameter("e_about"));
        user.setEmail(session.getAttribute("authUser").toString());
        try {
            usersOracleDAO.userUpdate(user);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("account.jsp").forward(req,resp);
    }
}
