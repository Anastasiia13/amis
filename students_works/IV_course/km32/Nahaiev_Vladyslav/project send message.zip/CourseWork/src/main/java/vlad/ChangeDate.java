package vlad;

public class ChangeDate {

    private static final String january = "JAN";
    private static final String february = "FEB";
    private static final String march = "MAR";
    private static final String april = "APR";
    private static final String may = "MAY";
    private static final String june = "JUN";
    private static final String july = "JUL";
    private static final String august = "AUG";
    private static final String september = "SEP";
    private static final String october = "OCT";
    private static final String november = "NOV";
    private static final String december = "DEC";


    private static String getYear(char[] date){
        String year = "";
        for (int i = 0; i < date.length; i++) {
            while (Character.isDigit(date[i])) {
                year += date[i];
                i++;
            }
            if (date[i] == '-') {
                break;
            }
        }
        return year;
    }

    private static String getDay(char[] date){
        String day = "";
        for (int i = date.length-1; i > 0; i--) {
            while (Character.isDigit(date[i])){
                day += date[i];
                i--;
            }
            if(date[i] == '-'){
                break;
            }
        }
        return new StringBuilder(day).reverse().toString();
    }

    private static int setMonth(char[] date){
        int j = 0;
        String number = "";
        for (int i = 0; i < date.length; i++) {
            if(date[i] == '-'){
                j = i+1;
                while (Character.isDigit(date[j])){
                    number += date[j];
                    j++;
                }
                i = j+1;
                if(date[i] == '-'){
                    break;
                }
            }
        }
        return Integer.parseInt(number);
    }

    private static String getMonth(int month){
        switch (month){
            case 1:
                return january;
            case 2:
                return february;
            case 3:
                return march;
            case 4:
                return april;
            case 5:
                return may;
            case 6:
                return june;
            case 7:
                return july;
            case 8:
                return august;
            case 9:
                return september;
            case 10:
                return october;
            case 11:
                return november;
            case 12:
                return december;
            default:
                return "Month not defined";
        }
    }
    public static String getDate(String date){
        int m = setMonth(date.toCharArray());
        return getDay(date.toCharArray()) + "-" + getMonth(m) + "-" + getYear(date.toCharArray());
    }
}
