function create_msg() {
    document.getElementById("42").style.display = 'block';
}

function close_form() {
    document.getElementById("42").style.display = 'none';
}
