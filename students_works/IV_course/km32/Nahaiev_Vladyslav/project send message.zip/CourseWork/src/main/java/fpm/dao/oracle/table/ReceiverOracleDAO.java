package fpm.dao.oracle.table;

import fpm.dao.oracle.OracleDAOFactory;
import fpm.dao.table.ReceiverDAO;
import fpm.entities.Receiver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReceiverOracleDAO implements ReceiverDAO {

    public boolean existReceiver(Receiver receiver) throws SQLException, ClassNotFoundException {
        Connection connection = null;
        String To = null;
        String check = "SELECT TRIM(EMAIL) AS Email FROM MAILBOX_USERS WHERE " +
                "Email = '" + receiver.getTo_email() + "'";
        try {
            connection = OracleDAOFactory.createConnection();
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(check);
            while (rs.next()) {
                To = rs.getString("EMAIL");
            }
            return receiver.getTo_email().equals(To);
        } finally {
            assert connection != null;
            connection.close();
        }
    }
}

