package fpm.dao.table;

import fpm.entities.Message;
import fpm.entities.Receiver;
import fpm.entities.User;

import java.sql.SQLException;
import java.util.List;

public interface MessageDAO {

    List<Message> inboxMessage(User user) throws SQLException, ClassNotFoundException;
    String send(Message message, Receiver receiver) throws SQLException, ClassNotFoundException;
    List<Message> sentMessage(User user) throws SQLException, ClassNotFoundException;
    List<Message> showUserMessage(String user_email) throws SQLException, ClassNotFoundException;
    void updateMessage(Message message, User user) throws SQLException;
}
