package fpm.servlets;

import fpm.dao.oracle.table.MessageOracleDAO;
import fpm.dao.table.MessageDAO;
import fpm.entities.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/sent")

public class Sent extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html; charset=UTF-8");
        HttpSession session = req.getSession(true);
        //session.getAttribute("authUser");
        MessageDAO sentMsg = new MessageOracleDAO();
        User user = new User();
        try {
            if(session.getAttribute("authUser") != null){
                user.setEmail(session.getAttribute("authUser").toString());
                session.setAttribute("Sent_messages", sentMsg.sentMessage(user));
            }else {
                resp.sendRedirect(Denied.redict());
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("sent.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("sent.jsp").forward(req,resp);
    }
}
