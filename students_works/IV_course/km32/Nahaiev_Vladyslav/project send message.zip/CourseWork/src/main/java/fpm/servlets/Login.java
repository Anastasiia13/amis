package fpm.servlets;

import fpm.dao.oracle.table.UsersOracleDAO;
import fpm.dao.table.UsersDAO;
import fpm.entities.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/log")

public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session;
        session = req.getSession();
        if(session.getAttribute("authUser") != null) {
            resp.sendRedirect(req.getContextPath() + "/main");
        }else {
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        //resp.setContentType("text/html");
        HttpSession session = req.getSession(true);;
        String email = req.getParameter("user_email");
        String pass = req.getParameter("user_pass");
        User user = new User();
        user.setEmail(email);
        user.setPassword(pass);
        UsersDAO user_worker = new UsersOracleDAO();
        boolean status = false;
        try {
            status = user_worker.userAuth(email, pass);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(status){
            session.setAttribute("authUser",email);
            resp.sendRedirect(req.getContextPath() + "/main");
            return;
        }else {
            session.setAttribute("valid","Invalid password/login");
        }
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }
}
