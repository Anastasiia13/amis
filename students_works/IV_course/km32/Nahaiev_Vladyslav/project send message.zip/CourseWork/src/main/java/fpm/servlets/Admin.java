package fpm.servlets;

import fpm.dao.oracle.table.MessageOracleDAO;
import fpm.dao.oracle.table.UsersOracleDAO;
import fpm.dao.table.MessageDAO;
import fpm.dao.table.UsersDAO;
import fpm.entities.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/panel")

public class Admin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        UsersDAO usersDAO = new UsersOracleDAO();
        MessageDAO messageDAO = new MessageOracleDAO();
        User admin = new User();
        HttpSession session = req.getSession(true);
        try {
            if (session.getAttribute("authUser") != null) {
                admin.setEmail(session.getAttribute("authUser").toString());
                if(usersDAO.getUserRole(admin) == 2) {
                    session.setAttribute("mail_users",usersDAO.showUsers());
                    //session.getAttribute("mail_user_messages",messageDAO.showUserMessage());
                }
            }
        } catch(SQLException e){
            e.printStackTrace();
        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        req.getRequestDispatcher("adminka.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UsersOracleDAO usersOracleDAO = new UsersOracleDAO();
        HttpSession session = req.getSession(true);
        if(req.getParameter("user_ban") != null){
            User user = new User();
            try {
                user.setEmail(req.getParameter("user_ban"));
                usersOracleDAO.ban(user);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        MessageDAO messageDAO = new MessageOracleDAO();
        if(req.getParameter("user_message_update") != null){
            String user_email = req.getParameter("user_message_update");
            try {
                session.setAttribute("mail_us_msg",messageDAO.showUserMessage(user_email));
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        req.getRequestDispatcher("adminka.jsp").forward(req,resp);
    }
}
