package fpm.entities;

public class Receiver {

    private String to_email;
    private String rec_send_date;
    private String send_from_email;
    private String read_message;

    public String getTo_email() {
        return to_email;
    }

    public void setTo_email(String to_email) {
        this.to_email = to_email;
    }

    public String getRec_send_date() {
        return rec_send_date;
    }

    public void setRec_send_date(String rec_send_date) {
        this.rec_send_date = rec_send_date;
    }

    public String getSend_from_email() {
        return send_from_email;
    }

    public void setSend_from_email(String send_from_email) {
        this.send_from_email = send_from_email;
    }

    public String getRead_message() {
        return read_message;
    }

    public void setRead_message(String read_message) {
        this.read_message = read_message;
    }
}
