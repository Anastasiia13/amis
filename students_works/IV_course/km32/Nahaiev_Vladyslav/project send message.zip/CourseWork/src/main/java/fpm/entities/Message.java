package fpm.entities;

public class Message {

    private String subject;
    private String messageText;
    private String sendDate;
    private String fromEmail;
    private String mesSendDate;
    private String mesFromEmail;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getMesSendDate() {
        return mesSendDate;
    }

    public void setMesSendDate(String mesSendDate) {
        this.mesSendDate = mesSendDate;
    }

    public String getMesFromEmail() {
        return mesFromEmail;
    }

    public void setMesFromEmail(String mesFromEmail) {
        this.mesFromEmail = mesFromEmail;
    }
}
