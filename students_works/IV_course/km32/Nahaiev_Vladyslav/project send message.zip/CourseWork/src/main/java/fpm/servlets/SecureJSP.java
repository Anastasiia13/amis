package fpm.servlets;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.HttpJspPage;
import java.io.IOException;

public abstract class SecureJSP extends HttpServlet
        implements HttpJspPage {
    public void destroy() {
        jspDestroy();
    }

    public void init() throws ServletException {
        jspInit();
    }

    public void jspDestroy() { }

    public void jspInit() { }

    public void service(HttpServletRequest request,
                        HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession(false);
        boolean isPassed = false;

        if (session != null) {
            if (session.getAttribute("authUser") != null)
                isPassed = true;
        }

        if (!isPassed) {
            forward(getErrorPageName(), request, response);
            return;
        }
        _jspService(request, response);
    }

    private void forward(String page, HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(page);
        dispatcher.forward(request, response);
    }

    private String getErrorPageName() {
        return "/denied.jsp";
    }
}