package fpm.dao.oracle.table;

import fpm.dao.oracle.OracleDAOFactory;
import fpm.dao.table.MessageDAO;
import fpm.entities.Message;
import fpm.entities.Receiver;
import fpm.entities.User;

import javax.ejb.EJBException;
import java.sql.Timestamp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageOracleDAO implements MessageDAO{

    //private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

    public List<Message> inboxMessage(User user) throws SQLException, ClassNotFoundException {
        List<Message> messages = new ArrayList<Message>();
        Connection conn = null;
/*        String getMsg = "CREATE OR REPLACE VIEW view_messages AS " +
                "SELECT SUBJECT, MESSAGE_TEXT,SEND_DATE,FROM_EMAIL FROM MESSAGE JOIN RECEIVER" +
                " ON MESSAGE.SEND_DATE = RECEIVER.REC_SEND_DATE" +
                " WHERE TO_EMAIL = '" + user.getEmail() + "'";*/

        String getMsg = "SELECT * FROM VIEW_MESSAGES WHERE TO_EMAIL = '" + user.getEmail() + "'";
        try {
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getMsg);
            while (rs.next()){
                /*messages.add(rs.getString("FROM_EMAIL") + "        " +
                rs.getString("SUBJECT") + "        " +
                rs.getString("MESSAGE_TEXT") + "        " +
                rs.getString("SEND_DATE"));*/
                Message msg = new Message();
                msg.setFromEmail(rs.getString("FROM_EMAIL"));
                msg.setSubject(rs.getString("SUBJECT"));
                msg.setMessageText(rs.getString("MESSAGE_TEXT"));
                msg.setSendDate(rs.getString("SEND_DATE"));
                messages.add(msg);
            }
        }finally {
            if(conn != null){
                conn.close();
            }
        }
        return messages;
    }
    public String send(Message message, Receiver receiver) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        CallableStatement cs;
        try {
            ReceiverOracleDAO receiverOracleDAO = new ReceiverOracleDAO();
            boolean exist = receiverOracleDAO.existReceiver(receiver);
            if(exist){
                //String currentTime = new Timestamp(System.currentTimeMillis()).toString();
                conn = OracleDAOFactory.createConnection();
                cs = conn.prepareCall("{call SEND_MSG(?,?,?,?,?)}");
                cs.setString(1,message.getFromEmail());
                cs.setString(2,receiver.getTo_email());
                cs.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                cs.setString(4 ,message.getSubject());
                cs.setString(5 ,message.getMessageText());
                cs.execute();
                cs.close();
                return "Message send!";
            }else {
                return "User isn't exist!";
            }
        }catch (SQLException e){
            return "Message not send!";
        }
        finally {
            if(conn != null) {
                conn.close();
            }
        }
    }
    public List<Message> sentMessage(User user) throws SQLException, ClassNotFoundException {
        List<Message> sent_messages = new ArrayList<Message>();
        Connection conn = null;
        String getSentMsg = "SELECT * FROM VIEW_MESSAGES WHERE FROM_EMAIL = '" + user.getEmail() + "'";
        try{
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getSentMsg);
            while (rs.next()){
/*                sent_messages.add(rs.getString("TO_EMAIL") + "        " +
                        rs.getString("SUBJECT") + "        " +
                        rs.getString("MESSAGE_TEXT") + "        " +
                        rs.getString("SEND_DATE"));*/
                Message msg = new Message();
                msg.setFromEmail(rs.getString("TO_EMAIL"));
                msg.setSubject(rs.getString("SUBJECT"));
                msg.setMessageText(rs.getString("MESSAGE_TEXT"));
                msg.setSendDate(rs.getString("SEND_DATE"));
                sent_messages.add(msg);
            }
        }finally {
            if(conn != null){
                conn.close();
            }
        }
        return sent_messages;
    }
    public List<Message> showUserMessage(String user_email) throws SQLException, ClassNotFoundException {
        List<Message> messagesUser = new ArrayList<Message>();
        Connection conn = null;
        String getUserMessages = "SELECT * FROM VIEW_MESSAGES WHERE FROM_EMAIL = '" + user_email + "'";
        try{
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getUserMessages);
            while (rs.next()){
                Message msg = new Message();
                msg.setSubject(rs.getString("SUBJECT"));
                msg.setMessageText(rs.getString("MESSAGE_TEXT"));
                msg.setSendDate(rs.getString("SEND_DATE"));
                msg.setFromEmail(rs.getString("TO_EMAIL"));
                messagesUser.add(msg);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            if(conn != null){
                conn.close();
            }
        }
        return messagesUser;
    }
    public void updateMessage(Message message, User user) throws SQLException {
        Connection conn = null;
        String updateMsg = "UPDATE MESSAGE SET MESSAGE_TEXT = '" + message.getMessageText() + "'" +
                " WHERE FROM_EMAIL = '" + user.getEmail() + "'";
        try{
            conn = OracleDAOFactory.createConnection();
            conn.setTransactionIsolation(2);
            conn.setAutoCommit(false);
            Statement statement = conn.createStatement();
            statement.executeUpdate(updateMsg);
            conn.commit();
        } catch (SQLException e) {
            if(conn != null) {
                conn.rollback();
            }
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(conn != null){
                conn.close();
            }
        }
    }
}
