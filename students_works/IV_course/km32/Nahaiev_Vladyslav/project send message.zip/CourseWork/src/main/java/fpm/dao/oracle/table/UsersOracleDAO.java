package fpm.dao.oracle.table;

import fpm.dao.oracle.OracleDAOFactory;
import fpm.entities.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public  class UsersOracleDAO implements fpm.dao.table.UsersDAO{

    public boolean userAuth(String email, String password) throws SQLException, ClassNotFoundException {
        String tableEmail = "";
        String tablePass = "";
        Connection conn = null;
        String auth = "SELECT TRIM(EMAIL) AS Email, TRIM(PASSWORD) AS Password FROM MAILBOX_USERS" +
                " WHERE Email = '" + email + "' AND Password = '" + password + "'";
        try {
            conn = OracleDAOFactory.createConnection();
            Statement statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(auth);
            while (rs.next()) {
                tableEmail = rs.getString("Email");
                tablePass = rs.getString("Password");
            }
        }catch (Exception e){
            e.printStackTrace();
            e.getStackTrace();
        }finally {
            if(conn != null) { //change
                conn.close();
            }
        }
        return email.equals(tableEmail) && password.equals(tablePass);
    }
    public boolean userReg(User user) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        CallableStatement cs;
        Statement statement;
        /*String registration = "INSERT INTO MAILBOX_USERS VALUES ('" +
                user.getEmail() + "','" + user.getFullName() + "','" + user.getPassword()
                + "','" + user.getBirthday() + "','" + user.getAbout() + "'," + 1 + "," + 0 + ")";*/
        try {
            conn = OracleDAOFactory.createConnection();
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery("SELECT TRIM(EMAIL) AS Email FROM MAILBOX_USERS WHERE Email = '" + user.getEmail() + "'");
            while (rs.next()) {
                String email = rs.getString("EMAIL");
                if (user.getEmail().equals(email)) {
                    return false;
                }
            }
            statement.close();
            cs = conn.prepareCall("{call REG_USER(?,?,?,?,?)}");
            cs.setString(1, user.getEmail());
            cs.setString(2, user.getPassword());
            cs.setDate(3, java.sql.Date.valueOf(user.getBirthday()));
            cs.setString(4, user.getAbout());
            cs.setString(5, user.getFullName());
            cs.execute();
            cs.close();
        }catch (SQLException e){
            e.getStackTrace();
        }finally {
            if(conn != null){ //change
                conn.close();
            }
        }
        return true;
    }
    public String[] userInfo(User user) throws SQLException, ClassNotFoundException{
        Connection conn = null;
        String[] info = new String[3];
        String getInfo = "SELECT TRIM(NAME_SURNAME) AS NAME_SURNAME,ABOUT,BIRTHDAY FROM MAILBOX_USERS WHERE EMAIL = '" + user.getEmail() + "'";
        try{
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getInfo);
            while (rs.next()){
                info[0] = rs.getString("NAME_SURNAME");
                info[1] = rs.getString("ABOUT");
                info[2] = rs.getString("BIRTHDAY");
            }
        }finally {
            if(conn != null){
                conn.close();
            }
        }
        return info;
    }
    public String userUpdate(User user) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        CallableStatement cs;
        try{
            conn = OracleDAOFactory.createConnection();
            cs = conn.prepareCall("{CALL EDIT_USER(?,?,?)}");
            cs.setString(1,user.getFullName());
            cs.setString(2,user.getAbout());
            cs.setString(3,user.getEmail());
            cs.execute();
            cs.close();
        }catch (SQLException e){
            e.printStackTrace();
            return "Error update!";
        }
        finally {
            if(conn != null){
                conn.close();
            }
        }
        return "Success update";
    }
    public String ban(User user) throws SQLException, ClassNotFoundException {
        Connection conn = null;
            CallableStatement cs;
        try{
            if(getUserRole(user) == 1) {
                conn = OracleDAOFactory.createConnection();
                cs = conn.prepareCall("{CALL MOD_BAN(?)}");
                cs.setString(1, user.getEmail());
                cs.execute();
                return "Commit!";
            }else {
                return "Not have permission";
            }
        }catch (SQLException e){
            e.printStackTrace();
            return "Rollback!";
        }finally {
            if(conn != null){
                conn.close();
            }
        }
    }
    public int getUserRole(User user) throws SQLException, ClassNotFoundException {
        int role = 0;
        Connection conn = null;
        String getRole = "SELECT ROLE_U FROM MAILBOX_USERS WHERE " +
                "EMAIL = '" + user.getEmail() + "'";
        try{
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getRole);
            while (rs.next()){
                role = rs.getInt("ROLE_U");
            }
            return role;
        }catch (SQLException e){
            e.printStackTrace();
            return 0;
        }finally {
            if(conn != null){
                conn.close();
            }
        }
    }
    public List<User> showUsers() throws SQLException, ClassNotFoundException {
        Connection conn = null;
        String getAllUsers = "SELECT * FROM VIEW_USERS";
        List<User> users = new ArrayList<User>();
        try{
            conn = OracleDAOFactory.createConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(getAllUsers);
            while (rs.next()){
                User user = new User();
                user.setEmail(rs.getString("EMAIL"));
                user.setFullName(rs.getString("NAME_SURNAME"));
                user.setBirthday(rs.getString("BIRTHDAY"));
                user.setAbout(rs.getString("ABOUT"));
                user.setRole(rs.getInt("ROLE_U"));
                user.setBan(rs.getInt("BAN"));
                users.add(user);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            if(conn != null){
                conn.close();
            }
        }
        return users;
    }
}

