package fpm.dao;

import fpm.dao.oracle.OracleDAOFactory;


import java.util.NoSuchElementException;

public abstract class DAOFactory {

    public final static int ORACLE = 1;
    public final static int MicrosoftAccess = 2;

    public static DAOFactory getDAOFactory(int type) {
        switch (type){
            case ORACLE:
                return new OracleDAOFactory();
            default:
                throw new NoSuchElementException();
        }
    }
}
