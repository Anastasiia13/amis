package fpm.dao.table;

import fpm.entities.User;

import java.util.List;
import java.sql.SQLException;

public interface UsersDAO {

    boolean userAuth(String name, String password) throws SQLException, ClassNotFoundException;
    boolean userReg(User user) throws SQLException, ClassNotFoundException;
    String[] userInfo(User user) throws SQLException, ClassNotFoundException;
    String userUpdate(User user) throws SQLException, ClassNotFoundException;
    String ban (User user) throws SQLException, ClassNotFoundException;
    int getUserRole(User user) throws SQLException, ClassNotFoundException;
    List<User> showUsers() throws SQLException, ClassNotFoundException;
}
