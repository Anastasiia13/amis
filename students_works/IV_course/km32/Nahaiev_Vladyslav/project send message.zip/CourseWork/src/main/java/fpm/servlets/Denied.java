package fpm.servlets;

public class Denied {

    public static String redict(){
        return "denied.jsp";
    }

}
