package fpm.servlets;

import fpm.dao.oracle.table.MessageOracleDAO;
import fpm.dao.table.MessageDAO;
import fpm.entities.Message;
import fpm.entities.Receiver;
import fpm.entities.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/main")

public class Mailbox extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        HttpSession session = req.getSession(true);
        MessageDAO msg = new MessageOracleDAO();
        User user = new User();
        try {
            if(session.getAttribute("authUser") != null) {
                user.setEmail(session.getAttribute("authUser").toString());
                session.setAttribute("User_messages", msg.inboxMessage(user));
            }else {
                resp.sendRedirect(Denied.redict());
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("mailbox.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(true);
        Message message = new Message();
        Receiver receiver = new Receiver();
        message.setSubject(req.getParameter("subj"));
        message.setMessageText(req.getParameter("msg"));
        message.setFromEmail(session.getAttribute("authUser").toString());
        receiver.setTo_email(req.getParameter("receiver"));
        try {
            String status = new MessageOracleDAO().send(message,receiver);
            session.setAttribute("msg_status",status);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("mailbox.jsp").forward(req,resp);
    }
}
