package fpm.dao.oracle;

import fpm.dao.DAOFactory;
import vlad.Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public final class OracleDAOFactory extends DAOFactory {

    final static String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
    final static String USER_LOGIN = "Mailbox_Sys";
    final static String USER_PASS = "M610917m";

    public static Connection createConnection() throws SQLException, ClassNotFoundException {
        Config config = new Config();
        Class.forName("oracle.jdbc.driver.OracleDriver");
        return DriverManager.getConnection(config.getDB_URL(),config.getUSER(),config.getPASS());
    }
}
