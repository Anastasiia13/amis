package fpm.dao.table;

import fpm.entities.Receiver;

import java.sql.SQLException;

public interface ReceiverDAO {

    boolean existReceiver(Receiver receiver) throws SQLException, ClassNotFoundException;
}
